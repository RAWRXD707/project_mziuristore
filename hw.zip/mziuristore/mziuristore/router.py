from ninja import Router
from .models import Category, Model
from .schemas import CategoryIn, CategoryOut, ModelIn, ModelOut

router = Router()